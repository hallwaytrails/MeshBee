#!/bin/bash

sudo apt -y install python3-tk
sudo apt -y install python3-venv
sudo apt -y install python3-dev
sudo apt -y install gcc
sudo dpkg -i meshnet_0.0.2_all.deb